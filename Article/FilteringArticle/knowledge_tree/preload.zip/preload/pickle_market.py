﻿# -*- encoding = gb18030 -*-

# package importing start
import re

import json

from file.file_operator import PickleOperator
# package importing end


class PickleMarket :

    def __init__(self) :
        pass

    def sentences_to_pickle(self, type='create', sentences=[], path='') :
        """ If type is 'create' :
                Initialize the word dictionary using sentences.
            If type is 'load' :
                Initialize the word dictionary from the file.
        """
        if type is 'create' :
            file_operator = PickleOperator()
            pickle_data = sentences
            file_operator.writing(pickle_data, path)
        elif type is 'load' :
            file_operator = PickleOperator()
            pickle_data = file_operator.reading(path)
        print len(pickle_data)
        return pickle_data