﻿# -*- encoding = gb18030 -*-

# package importing start
import sys

import gensim

from preload.pickle_market import PickleMarket
from basic.word import Word
from file.file_operator import TextFileOperator
# package importing end


class Corpus :

    def __init__(self) :
        pass

    def run_create_pickle(self, sentence_path, \
        json_path) :
        sentences = self.read_sentences(sentence_path)
        loader = PickleMarket()
        json_market = loader.sentences_to_pickle(type='create', sentences=sentences, path=json_path)

    def run_load_pickle(self, json_path) :
        loader = PickleMarket()
        json_market = loader.sentences_to_pickle(type='load', path=json_path)
        return json_market

    def read_sentences(self, source_path) :
        """ Read participle sentences.
            Each row is a sentence.
        """
        file_operator = TextFileOperator()
        data_list = file_operator.reading(source_path)
        entry_list = data_list[0]
        sentences = list()
        length = len(data_list[1:])
        for idx, data in enumerate(data_list[1:]) :
            if len(data) >= len(entry_list) :
                sentence = [Word(word, sp_char=':').to_string() for word in data[0].split(' ')]
                sentences.append(sentence)
            if idx % 100 == 0 :
                print 'finish rate is %.2f%%\r' % (100.0*idx/length),
        print 
        return sentences