﻿# -*- encoding = gb18030 -*-

# package importing start
# package importing end


class BaseExtractor :
    
    def __init__(self) :
        pass
    
    def extractFeature(self, article_list) :
        """ Extract feature of the article. """
        return article_list
